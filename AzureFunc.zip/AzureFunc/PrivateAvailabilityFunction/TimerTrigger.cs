using Microsoft.ApplicationInsights.Extensibility;
using System;using System.Threading.Tasks;
using System.Net.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;

public static class TimerTrigger
{
    private static readonly HttpClient client = new HttpClient();
    private static TelemetryClient telemetryClient =
    new TelemetryClient(Microsoft.ApplicationInsights.Extensibility.TelemetryConfiguration.CreateDefault());

    [FunctionName("TimerTrigger")]
    public static async Task Run(
        [TimerTrigger("0 */5 * * * *")] TimerInfo myTimer,
        ILogger log)
    {
        log.LogInformation("Private availability check started");

        var availability = new AvailabilityTelemetry
        {
            Name = "Private-App-Test",
            RunLocation = Environment.MachineName,
            Success = false,
            Timestamp = DateTimeOffset.UtcNow
        };

        var start = DateTime.UtcNow;

        try
        {
            var response = await client.GetAsync("http://10.0.0.10");

            availability.Success = response.IsSuccessStatusCode;
            availability.Message = response.StatusCode.ToString();

            if (availability.Success)
                log.LogInformation("PRIVATE_APP_SUCCESS");
            else
                log.LogError("PRIVATE_APP_FAILED");
        }
        catch (Exception ex)
        {
            availability.Success = false;
            availability.Message = ex.Message;
            log.LogError($"PRIVATE_APP_FAILED: {ex.Message}");
        }

        availability.Duration = DateTime.UtcNow - start;

        telemetryClient.TrackAvailability(availability);
        telemetryClient.Flush();
    }
}
